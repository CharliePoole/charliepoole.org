This project contains the sample files for the final version of
the CSharpAddTestFixtureWiz wizard described in the series of
articles "C# Wizardry" available at
	www.charliepoole.org/cp.php?p=cswizardry_part1
	www.charliepoole.org/cp.php?p=cswizardry_part2
	www.charliepoole.org/cp.php?p=cswizardry_part3

Questions or comments can be addressed to me at
	cpoole@pooleconsulting.com

All code as well as the text of the articles is 

	Copyight � 2002 Charlie Poole. All rights reserved.

